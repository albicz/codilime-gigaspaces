#! /bin/bash -e

ctx instance runtime-properties op2_prop op2_value
ctx returns op2_called
