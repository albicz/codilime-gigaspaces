cosmo-plugin-agent-installer
============================

- Build Status (develop branch) [![Build Status](https://secure.travis-ci.org/CloudifySource/cosmo-plugin-agent-installer.png?branch=develop)](http://travis-ci.org/CloudifySource/cosmo-plugin-agent-installer)

cosmo plugin for installing a cosmo agent on a remote or a local machine.
