cosmo-plugin-plugin-installer
=============================

- Build Status (develop branch) [![Build Status](https://secure.travis-ci.org/CloudifySource/cosmo-plugin-plugin-installer.png?branch=develop)](http://travis-ci.org/CloudifySource/cosmo-plugin-plugin-installer)

cosmo plugin for installing additional plugins.

