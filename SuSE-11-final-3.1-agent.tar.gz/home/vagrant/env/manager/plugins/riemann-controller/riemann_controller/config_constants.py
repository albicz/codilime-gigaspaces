
class Constants:
    PERIODICAL_EXPIRATION_INTERVAL = 5  # in seconds
